package io.flutter;

public class bostyfields_flutter_app {
}
