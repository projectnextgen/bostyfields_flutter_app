// main.dart
import 'dart:async';
import 'dart:convert';
import 'package:bostyfield_app/network_utils/api.dart';
import 'package:bostyfield_app/screen/success.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:bostyfield_app/.env.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'home.dart';
import 'login.dart';

class PaymentScreen extends StatefulWidget {
  @override
  PaymentScreenState createState() => new PaymentScreenState();
}
// payment_screen.dart
class PaymentScreenState extends State<PaymentScreen>{
  bool _isLoading = false;
  _startLoading() {
    setState(() {
      _isLoading = true;
    });
    Timer(Duration(seconds: 2), () {
      setState(() {
        _isLoading = false;
      });
    });
  }
  String? name;
  String? amount;
  String? bookingreference;
  String? fieldname;
  String? productname;
  String? datetime;
  var booking;

  Future<String> getData() async {
    Stripe.publishableKey = stripePublishableKey;
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    var user = jsonDecode(localStorage.getString('user')!);
    var booking = jsonDecode(localStorage.getString('booking')!);

    if(user != null) {
      setState(() {
        name = user['firstname'];
      });
    }

    if(booking != null) {
      setState(() {
        bookingreference = booking['bookingreference'];
        fieldname = booking['fieldname'];
        productname = booking['productname'];
        datetime = booking['datetime'];
        amount = booking['amount'];
      });
    }
    print(bookingreference);
    print(fieldname);
    print(productname);
    print(datetime);
    print(amount);

    return 'Success';
  }
  @override
  void initState(){
    super.initState();
    this.getData();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('BostyFields.co.uk',style: GoogleFonts.prompt(fontWeight: FontWeight.w500)),
        backgroundColor: Colors.green[600],
      ),
      drawer: Drawer(
        // Add a ListView to the drawer. This ensures the user can scroll
        // through the options in the drawer if there isn't enough vertical
        // space to fit everything.
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.lightGreen,
                image: DecorationImage(
                  image: AssetImage(
                      'assets/images/drawerimage.jpg'),
                  fit: BoxFit.fill,
                ),
              ),
              child: Text('Hi, $name', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
            ),
            ListTile(
              title: Text('Book a Walk'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  new MaterialPageRoute(
                      builder: (context) => Home()
                  ),
                );
              },
            ),
            ListTile(
              title: Text('Item 2'),
              onTap: () {
                // Update the state of the app
                // ...
                // Then close the drawer
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('Logout'),
              onTap: () {
                logout(context);
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),

      body: Column(
        children: [
          Container(
              margin: const EdgeInsets.all(5.0),
              padding: const EdgeInsets.all(5.0),
              color: Colors.grey[200],
              child: Column(
              children: [
                Text(
                  bookingreference!, textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black45,
                    fontSize:18.0,
                    fontWeight: FontWeight.bold,
                    height: 1.2,
                  ),
                ),
                Text(
                  fieldname!, textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black45,
                    fontSize:18.0,
                    fontWeight: FontWeight.bold,
                    height: 1.2,
                  ),
                ),
                Text(
                  productname!, textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black45,
                    fontSize:18.0,
                    fontWeight: FontWeight.bold,
                    height: 1.2,
                  ),
                ),
                Text(
                  datetime!, textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black45,
                    fontSize:18.0,
                    fontWeight: FontWeight.bold,
                    height: 1.2,
                  ),
                ),
                Text(
                  amount!, textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black45,
                    fontSize:18.0,
                    fontWeight: FontWeight.bold,
                    height: 1.2,
                  ),
                ),
              ],
            )
          ),
          Container(
              margin: const EdgeInsets.all(20.0),
              child: Column(
                children: [
                  CardField(
                    onCardChanged: (card) {
                    print(card);
                    },
                  ),
                  TextButton(
                    onPressed: () async {
                    processpayment();
                    },
                    child: Text('Pay'),
                  )
                ],
              )
          )
        ],
      ),

    );
  }
  void processpayment() async {
    final paymentMethod =
    await Stripe.instance.createPaymentMethod(PaymentMethodParams.card());
    var data = {
      'id': paymentMethod.id,
    };
    print(paymentMethod.id);
    var res = await Network().sendPayment(data, '/payment');
    var result = json.decode(res.body);
    print(result);
    if (result['success'] == true) {
      SharedPreferences localStorage = await SharedPreferences.getInstance();
      Navigator.push(
        context,
        new MaterialPageRoute(
            builder: (context) => Success()
        ),
      );
    }
  }

  void logout(context) async{
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    localStorage.remove('user');
    localStorage.remove('access_token');
    localStorage.remove('token_type');
    Navigator.push(
        context,
        MaterialPageRoute(builder: (context)=>Login()));
  }
}
