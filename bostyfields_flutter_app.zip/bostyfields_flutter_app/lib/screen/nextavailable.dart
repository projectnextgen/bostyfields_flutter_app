import 'dart:async';
import 'dart:core';
import 'dart:convert';
import 'package:bostyfield_app/screen/availabletimes.dart';
import 'package:bostyfield_app/screen/payment.dart';
import 'package:flutter/material.dart';
// ignore: import_of_legacy_library_into_null_safe
import 'package:flutter_html/flutter_html.dart';
import 'package:flutter_html/html_parser.dart';
// ignore: import_of_legacy_library_into_null_safe
import 'package:flutter_html/style.dart';
import 'package:bostyfield_app/screen/home.dart';
import 'package:bostyfield_app/screen/login.dart';
import 'package:bostyfield_app/network_utils/api.dart';
import 'package:google_fonts/google_fonts.dart';
// ignore: import_of_legacy_library_into_null_safe
import 'package:shared_preferences/shared_preferences.dart';

class NextAvailable extends StatefulWidget {
  @override
  _NextAvailableState createState() => _NextAvailableState();
}

class _NextAvailableState extends State<NextAvailable>{
  bool _isLoading = false;
  _startLoading() {
    setState(() {
      _isLoading = true;
    });
    Timer(Duration(seconds: 2), () {
      setState(() {
        _isLoading = false;
      });
    });
  }
  final _formKey = GlobalKey<FormState>();
  var email;
  var password;

  final _scaffoldKey = GlobalKey<ScaffoldState>();

  _showMsg(msg) {
    final snackBar = SnackBar(
      content: Text(msg),
      action: SnackBarAction(
        label: 'Close',
        onPressed: () {
          // Some code to undo the change!
        },
      ),
    );
    // ignore: deprecated_member_use
    _scaffoldKey.currentState!.showSnackBar(snackBar);
  }
  @override
  void initState(){
    super.initState();
    _loadUserData();
  }

  String? name;
  String? fielddate1;
  String? fielddate2;
  String? fielddate3;
  String? fielddate4;
  String? selecteddate;
  final _htmlContent = """
      <div class='col-lg-12 p-0 border bookingcolumn'>
        <div class='serviceimagecontainer'>							
					  <div class="pb-4 border-bottom">
						  <h2>NEXT AVAILABLE DATES</h2>                                                                                                                                                                                                                                                      </h2></h2>
					  </div>
				</div>
				<div class='serviceimagecontainer1'>				
					  <div class='pb-4 border-bottom'>
					    <h2>Wenlock Walk</h2>
              <a href='1'>
                <div class='button'>
                  <h3><date1></date1></h3>                      
                </div>
               </a>                                                                                                                                                                                                                                                                                  
					  </div>
				</div>

				<div class='serviceimagecontainer2'>		
            <div class='pb-4 border-bottom'>
              <h2>Linley Leap</h2>
              <a href='2'>
              <div class='button'>
                <h3><date2></date2></h3>
              </div>
              </a>
            </div>
				</div>

				<div class='serviceimagecontainer1'>														
            <div class='pb-4 border-bottom'>
              <h3>Fae</h3>
              <a href='3'>
              <div class='button'>
                <h3><date3></date3></h3>
              </div>
              </a>
            </div>
				</div>
				<div class='serviceimagecontainer2'>
            <div class='pb-4 border-bottom'>
              <h3>Troll</h3>
              <a href='4'>
              <div class='button'>
                <h3><date4></date4></h3>
              </div>
              </a>
            </div>
				</div>
    """ ;

  var booking;

  _loadUserData() async{
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    var user = jsonDecode(localStorage.getString('user')!);

    var field1 = jsonDecode(localStorage.getString('field1')!);
    var field2 = jsonDecode(localStorage.getString('field2')!);
    var field3 = jsonDecode(localStorage.getString('field3')!);
    var field4 = jsonDecode(localStorage.getString('field4')!);

    if(user != null) {
      setState(() {
        name = user['firstname'];
      });
    }
    if(field1 != null) {
      setState(() {
        fielddate1 = field1;
      });
    }
    if(field2 != null) {
      setState(() {
        fielddate2 = field2;
      });
    }
    if(field3 != null) {
      setState(() {
        fielddate3 = field3;
      });
    }
    if(field4 != null) {
      setState(() {
        fielddate4 = field4;
      });
    }
    print(fielddate1);
    print(fielddate2);
    print(fielddate3);
    print(fielddate4);
  }


    @override
    Widget build(BuildContext context) {
        return Scaffold(
          key: _scaffoldKey,
          appBar: AppBar(
            title: Text('BostyFields.co.uk',style: GoogleFonts.prompt(fontWeight: FontWeight.w500)),
            backgroundColor: Colors.green[600],
          ),
          drawer: Drawer(
            // Add a ListView to the drawer. This ensures the user can scroll
            // through the options in the drawer if there isn't enough vertical
            // space to fit everything.
            child: ListView(
              // Important: Remove any padding from the ListView.
              padding: EdgeInsets.zero,
              children: <Widget>[
                DrawerHeader(
                  decoration: BoxDecoration(
                    color: Colors.lightGreen,
                    image: DecorationImage(
                      image: AssetImage(
                          'assets/images/drawerimage.jpg'),
                      fit: BoxFit.fill,
                    ),
                  ),
                  child: Text('Hi, $name', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
                ),
                ListTile(
                  title: Text('Book a Walk'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) => Home()
                      ),
                    );
                  },
                ),
                ListTile(
                  title: Text('Item 2'),
                  onTap: () {
                    // Update the state of the app
                    // ...
                    // Then close the drawer
                    Navigator.pop(context);
                  },
                ),
                ListTile(
                  title: Text('Logout'),
                  onTap: () {
                    logout();
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ),
              body: _isLoading ? Center(child: CircularProgressIndicator(valueColor:AlwaysStoppedAnimation<Color>(Colors.green[600]!))) : Container(
                child: SingleChildScrollView(
                  child: Html(
                    data: _htmlContent,
                    onLinkTap: (selectedfield, _, __, ___){
                      _selection(selectedfield);
                    },
                    customRender: {
                      "date1": (RenderContext context, Widget child) {
                        return TextSpan(text: "$fielddate1");
                      },
                      "date2": (RenderContext context, Widget child) {
                        return TextSpan(text: "$fielddate2");
                      },
                      "date3": (RenderContext context, Widget child) {
                        return TextSpan(text: "$fielddate3");
                      },
                      "date4": (RenderContext context, Widget child) {
                        return TextSpan(text: "$fielddate4");
                      },
                    },
                    tagsList: Html.tags..addAll(["date1", "date2", "date3", "date4"]),
                    // Styling with CSS (not real CSS)
                    style: {
                      'html': Style(
                        backgroundColor: Colors.white38,
                      ),
                      'h1': Style(
                          color: Colors.black87,
                          fontSize: FontSize.large
                      ),
                      'h2': Style(
                          color: Colors.white,
                          fontSize: FontSize.large,
                          fontWeight: FontWeight.w700
                      ),
                      'h3': Style(
                          color: Colors.white,
                          fontSize: FontSize.large
                      ),
                      'a': Style(
                        color: Colors.white,
                        fontSize: FontSize.large,
                        textDecoration: TextDecoration.none,
                      ),
                      'p': Style(
                          color: Colors.black87,
                          fontSize: FontSize.large
                      ),
                      '.bookingcolumn': Style(
                          textAlign: TextAlign.center,
                          fontSize: FontSize.large
                      ),
                      '.serviceimagecontainer': Style(
                        textAlign: TextAlign.center,
                        fontSize: FontSize.large,
                        color: Colors.black87,
                        backgroundColor: Colors.green[600],
                        padding: EdgeInsets.all(20),
                      ),
                      '.serviceimagecontainer1': Style(
                        textAlign: TextAlign.center,
                        fontSize: FontSize.large,
                        backgroundColor: Colors.lightGreen,
                        padding: EdgeInsets.all(20),
                      ),
                      '.serviceimagecontainer2': Style(
                        textAlign: TextAlign.center,
                        fontSize: FontSize.large,
                        backgroundColor: Colors.green[400],
                        padding: EdgeInsets.all(20),
                      ),
                      '.button': Style(
                        textAlign: TextAlign.center,
                        fontSize: FontSize.large,
                        backgroundColor: Colors.green[600],
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        padding: EdgeInsets.all(1),
                        margin: EdgeInsets.only(top:20, left: 50, right: 50, bottom: 0),
                      ),
                    },
                  ),
                ),
              ),
            );
      }

void _selection(selectedfield) async{
    _startLoading();

    SharedPreferences localStorage = await SharedPreferences.getInstance();
    localStorage.setString('selectedfield', selectedfield);

    if(selectedfield=="1"){
      selecteddate = fielddate1;
    };
    if(selectedfield=="2"){
      selecteddate = fielddate2;
    };
    if(selectedfield=="3"){
      selecteddate = fielddate3;
    };
    if(selectedfield=="4"){
      selecteddate = fielddate4;
    };

    localStorage.setString('selecteddate', selecteddate!);

    var res = await Network().getPostData("/bookings/"+selectedfield+"/"+selecteddate!);
    var times = json.decode(res.body);
    var entimes = json.encode(res.body);

    print(entimes);

    localStorage.setString("times", entimes);

    // ignore: unnecessary_null_comparison
    if(json.encode(times) != null){
      Navigator.push(
          context,
          MaterialPageRoute(builder: (context)=>AvailableTimes()));
    }else{
      _showMsg(times['message']);
    }

  }
void logout() async{
  SharedPreferences localStorage = await SharedPreferences.getInstance();
  localStorage.remove('user');
  localStorage.remove('access_token');
  localStorage.remove('token_type');
  Navigator.push(
      context,
      MaterialPageRoute(builder: (context)=>Login()));
}
}
